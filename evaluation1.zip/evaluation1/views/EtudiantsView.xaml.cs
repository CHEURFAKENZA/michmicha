﻿
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace GestiCoop_ua1.views
{
    public partial class EtudiantsView : UserControl
    {
        List<Etudiant> etudiants = new List<Etudiant>();

        public EtudiantsView()
        {
            InitializeComponent();

            etudiants.Add(new Etudiant("Tremblay", "Sophie", "Informatique", "s.tremblay@etud.lacite.ca"));
            etudiants.Add(new Etudiant("Nguyen", "Minh", "Informatique", "m.nguyen@etud.lacite.ca"));
            etudiants.Add(new Etudiant("Dubois", "Élodie", "Génie logiciel", "e.dubois@etud.lacite.ca"));
            etudiants.Add(new Etudiant("Okonkwo", "Chidi", "Cybersécurité", "c.okonkwo@etud.lacite.ca"));
            etudiants.Add(new Etudiant("Lavoie", "Xavier", "Informatique", "x.lavoie@etud.lacite.ca"));

            Afficher();
        }

        private void Afficher()
        {
            string recherche = Recherche.Text.ToLower();
            string programme = "Tous les programmes";

            if (Programmes.SelectedItem is ComboBoxItem item)
            {
                programme = item.Content.ToString();
            }

            var liste = etudiants.Where(e =>
                (e.Nom.ToLower().Contains(recherche) ||
                 e.Prenom.ToLower().Contains(recherche) ||
                 e.Courriel.ToLower().Contains(recherche)) &&
                (programme == "Tous les programmes" ||
                 e.Programme == programme)).ToList();

            Tableau.ItemsSource = liste;
            Nombre.Text = liste.Count + " étudiants";
        }

        private void Filtrer(object sender, RoutedEventArgs e)
        {
            if (Tableau != null && Recherche != null && Programmes != null)
            {
                Afficher();
            }
        }

        private void Ajouter_Click(object sender, RoutedEventArgs e)
        {
            AjouterEtudiantWindow fenetre = new AjouterEtudiantWindow();
            fenetre.Owner = Window.GetWindow(this);

            if (fenetre.ShowDialog() == true)
            {
                etudiants.Add(fenetre.NouvelEtudiant);
                Afficher();
            }
        }

        private void Modifier_Click(object sender, RoutedEventArgs e)
        {
            Etudiant etudiant = (sender as Button).DataContext as Etudiant;

            if (etudiant != null)
            {
                OuvrirFormulaire(etudiant);
            }
        }

        private void Supprimer_Click(object sender, RoutedEventArgs e)
        {
            Etudiant etudiant = (sender as Button).DataContext as Etudiant;

            if (etudiant != null)
            {
                if (MessageBox.Show("Supprimer cet étudiant ?",
                    "Confirmation",
                    MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    etudiants.Remove(etudiant);
                    Afficher();
                }
            }
        }

        private void OuvrirFormulaire(Etudiant etudiant)
        {
            Window fenetre = new Window();
            fenetre.Title = "Modifier un étudiant";
            fenetre.Width = 350;
            fenetre.Height = 390;
            fenetre.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            StackPanel panneau = new StackPanel();
            panneau.Margin = new Thickness(20);

            TextBox nom = new TextBox();
            TextBox prenom = new TextBox();
            TextBox courriel = new TextBox();
            ComboBox programme = new ComboBox();

            programme.Items.Add("Informatique");
            programme.Items.Add("Génie logiciel");
            programme.Items.Add("Cybersécurité");

            nom.Text = etudiant.Nom;
            prenom.Text = etudiant.Prenom;
            courriel.Text = etudiant.Courriel;
            programme.SelectedItem = etudiant.Programme;

            panneau.Children.Add(new TextBlock { Text = "Nom" });
            panneau.Children.Add(nom);

            panneau.Children.Add(new TextBlock
            {
                Text = "Prénom",
                Margin = new Thickness(0, 12, 0, 0)
            });
            panneau.Children.Add(prenom);

            panneau.Children.Add(new TextBlock
            {
                Text = "Programme",
                Margin = new Thickness(0, 12, 0, 0)
            });
            panneau.Children.Add(programme);

            panneau.Children.Add(new TextBlock
            {
                Text = "Courriel",
                Margin = new Thickness(0, 12, 0, 0)
            });
            panneau.Children.Add(courriel);

            Button enregistrer = new Button();
            enregistrer.Content = "Enregistrer";
            enregistrer.Height = 35;
            enregistrer.Margin = new Thickness(0, 20, 0, 0);

            enregistrer.Click += (s, e) =>
            {
                if (nom.Text.Trim() == "" ||
                    prenom.Text.Trim() == "" ||
                    courriel.Text.Trim() == "")
                {
                    MessageBox.Show("Remplissez tous les champs.");
                    return;
                }

                etudiant.Nom = nom.Text.Trim();
                etudiant.Prenom = prenom.Text.Trim();
                etudiant.Programme = programme.SelectedItem.ToString();
                etudiant.Courriel = courriel.Text.Trim();

                Afficher();
                fenetre.Close();
            };

            panneau.Children.Add(enregistrer);
            fenetre.Content = panneau;
            fenetre.ShowDialog();
        }
    }

    public class Etudiant
    {
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Programme { get; set; }
        public string Courriel { get; set; }

        public Brush Couleur
        {
            get
            {
                if (Programme == "Informatique")
                {
                    return Brushes.LightBlue;
                }

                if (Programme == "Génie logiciel")
                {
                    return Brushes.LightGreen;
                }

                return Brushes.Khaki;
            }
        }

        public Etudiant(string nom, string prenom,
                        string programme, string courriel)
        {
            Nom = nom;
            Prenom = prenom;
            Programme = programme;
            Courriel = courriel;
        }
    }
}


