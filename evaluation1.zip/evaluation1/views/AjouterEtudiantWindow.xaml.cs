﻿
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace GestiCoop_ua1.views
{
    public partial class AjouterEtudiantWindow : Window
    {
        public Etudiant NouvelEtudiant { get; set; }

        public AjouterEtudiantWindow()
        {
            InitializeComponent();
        }

        private void Verifier(object sender, RoutedEventArgs e)
        {
            if (Nom == null || Prenom == null ||
                Courriel == null || Programme == null ||
                Numero == null || Enregistrer == null ||
                ErreurCourriel == null)
            {
                return;
            }

            bool courrielValide = Regex.IsMatch(
                Courriel.Text,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$");

            bool numeroValide = Numero.Text == "" ||
                Regex.IsMatch(Numero.Text, @"^\d{7}$");

            if (Courriel.Text != "" && !courrielValide)
            {
                ErreurCourriel.Visibility = Visibility.Visible;
            }
            else
            {
                ErreurCourriel.Visibility = Visibility.Collapsed;
            }

            Enregistrer.IsEnabled =
                Nom.Text.Trim() != "" &&
                Prenom.Text.Trim() != "" &&
                courrielValide &&
                Programme.SelectedItem != null &&
                numeroValide;
        }

        private void Annuler_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void Enregistrer_Click(object sender, RoutedEventArgs e)
        {
            ComboBoxItem choix = Programme.SelectedItem as ComboBoxItem;

            NouvelEtudiant = new Etudiant(
                Nom.Text.Trim(),
                Prenom.Text.Trim(),
                choix.Content.ToString(),
                Courriel.Text.Trim());

            DialogResult = true;
        }
    }
}
