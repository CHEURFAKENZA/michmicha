﻿using System.Windows;
using System.Windows.Controls;
using GestiCoop_ua1.views;

namespace GestiCoop_ua1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Etudiants_Click(null, null);
        }

        private void Tableau_Click(object sender, RoutedEventArgs e)
        {
            TitrePage.Text = "Tableau de bord";
            Contenu.Children.Clear();

            TextBlock texte = new TextBlock();
            texte.Text = "Bienvenue sur GestiCoop";
            texte.FontSize = 20;
            texte.HorizontalAlignment = HorizontalAlignment.Center;
            texte.VerticalAlignment = VerticalAlignment.Center;

            Contenu.Children.Add(texte);
        }

        private void Etudiants_Click(object sender, RoutedEventArgs e)
        {
            TitrePage.Text = "Liste des étudiants";
            Contenu.Children.Clear();
            Contenu.Children.Add(new EtudiantsView());
        }
    }
}

